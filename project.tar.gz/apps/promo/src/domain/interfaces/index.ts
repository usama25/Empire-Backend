export * from './promo.repository';
