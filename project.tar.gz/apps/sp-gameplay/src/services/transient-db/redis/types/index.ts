export type RedisKey = string;

export type RedisValue = string | number | object | null;
