/* eslint-disable unicorn/prevent-abbreviations */
/* eslint-disable no-var */

declare var e2EServiceManager: E2EServiceManager;
declare var server: any;
declare var mongodb: MongoMemoryServer;
