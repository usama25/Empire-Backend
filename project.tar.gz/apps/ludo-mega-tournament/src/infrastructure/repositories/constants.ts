export const TABLE_KEY = '{ludoMegaTournamentGameTable}';
export const USER_TABLE_CACHE_KEY = '{ludoMegaTournamentUserTable}';
