export type GetLeaderboardRequest = {
  tournamentId: string;
  userId: string;
  skip: number;
  limit: number;
};
