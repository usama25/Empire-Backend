export const TABLE_KEY_PREFIX = '{EPLGameTable}';
export const USER_TABLE_CACHE_KEY = '{UserActiveTable}';
export const USER_WAITING_KEY = '{UserWaitingKey}';
export const BIG_TABLE_USER_KEY = '{EPLBigTableUsers}';
