export class WalletEntity {
  constructor(
    public main: string,
    public win: string,
    public bonus: string,
  ) {}
}
