export type LudoMegaTournamentConfig = {
  underMaintenance: boolean;
  features: {
    isExtraRollAfterSixEnabled: boolean;
  };
};
