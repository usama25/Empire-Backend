export * from './ludo-config.interface';
export * from './epl-config.interface';
export * from './ludo-mega-tournament-config.interface';
