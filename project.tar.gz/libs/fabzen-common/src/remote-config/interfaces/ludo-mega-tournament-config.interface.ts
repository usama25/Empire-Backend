export abstract class LudoMegaTournamentRemoteConfigService {
  abstract isUnderMaintenance(): boolean;
  abstract isExtraRollAfterSixEnabled(): boolean;
}
