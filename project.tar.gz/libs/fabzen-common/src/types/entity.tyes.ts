import { Types } from 'mongoose';

export type EntityID = Types.ObjectId;
