export type BullQueueJob<T> = {
  data: T;
};
