export enum Games {
  empiregames = 'empiregames',
  ludo = 'ludo',
  ludoMegaTournament = 'ludoMegaTournament',
  rummyempire = 'rummy',
  skillpatti = 'skillpatti',
  callbreak = 'callbreak',
  snakeAndLadders = 'snakesandladders',
  cricket = 'cricket',
  aviator = 'aviator',
  epl = 'handcricket',
}

export enum DWM {
  day = 'day',
  week = 'week',
  month = 'month',
}
