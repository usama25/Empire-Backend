export type WinningPrize = {
  minRank: number;
  maxRank: number;
  amount: string;
  percentage: number;
};
